namespace TercerEjercioOOP
{
    public interface Shape
    {
        public double GetPerimeter();

        public double GetArea();
    }
}